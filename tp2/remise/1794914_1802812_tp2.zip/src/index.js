var json2csv = require('json2csv');

// Pour lire les params de la console
const ALGO = (process.argv.length > 2) ? process.argv[2] : null;
const PATH = (process.argv.length > 3) ? [process.argv[3]] : "nopath";
const OPTION1 = (process.argv.length > 4) ? [process.argv[4]] : null;
const OPTION2 = (process.argv.length > 5) ? [process.argv[5]] : null;

// Pour definir si on imprime le temps ou la tour
var PRINT_TOWER = false;
var PRINT_TIME = false;

if (!ALGO && ALGO !== 'vorace' && ALGO != 'progdyn' && ALGO != 'tabou') {
  throw "No algorithm was specified. Use: 'tp.sh -a $ALGO -e $PATH'  ALGO in: vorace, progdyn, tabou";
}

if (PATH === "nopath") {
  throw "No path specified. Use: 'tp.sh -a $ALGO -e $PATH' PATH example: data/b100_2.txt"
}

if (!OPTION1) {
  console.log("No options specified. Use: -p or -t")
} else {

  if (OPTION1[0].includes('-t')) {
    PRINT_TIME = true;
  }

  if (OPTION1[0].includes('-p')) {
    PRINT_TOWER = true;
  }

  if (OPTION2) {
    if (OPTION2[0].includes('-t')) {
      PRINT_TIME = true;
    }

    if (OPTION2[0].includes('-p')) {
      PRINT_TOWER = true;
    }
  }
}

// On set les valeurs pour qu'elles soient accessibles globalement.
global.PATH = PATH[0]
global.PRINT_TIME = PRINT_TIME
global.PRINT_TOWER = PRINT_TOWER

if (ALGO === 'vorace') {
  require('./vorace')
}

if (ALGO === 'progdyn') {
  require('./progdyn')
}

if (ALGO === 'tabou') {
  require('./tabou')
}
