# pris de : http://rosettacode.org/wiki/Sorting_algorithms/Merge_sort#Python
# pris de : http://rosettacode.org/wiki/Sorting_algorithms/Selection_sort#Python

import sys
import datetime
from heapq import merge

# Ouverture d'un fichier testset
file = open(str(sys.argv[1]), "r")
data = file.readlines()
data = map(int, [x.strip() for x in data])

def selection_sort(lst):
    for i, e in enumerate(lst):
        mn = min(range(i,len(lst)), key=lst.__getitem__)
        lst[i], lst[mn] = lst[mn], e
    return lst

def merge_sort(m):
	if len(m) <= 1:
		return m
		
	# seuil de recursivite	
	elif len(m) <= 10:
		return selection_sort(m)
		
	else:
		middle = len(m) // 2
		left = m[:middle]
		right = m[middle:]
		
		left = merge_sort(left)
		right = merge_sort(right)
		return list(merge(left,right))		

# Execution du tri et mesure du temps
time_init = datetime.datetime.now() 
result = merge_sort(data)
time_end = datetime.datetime.now()
time_delta = time_end - time_init

# Verification des parametres fournis (testset apres tri, temps de tri)
if "-p" in sys.argv or "--print" in sys.argv:
    for i in result:
        print i

if "-t" in sys.argv or "--time" in sys.argv:
    print time_delta.total_seconds()
