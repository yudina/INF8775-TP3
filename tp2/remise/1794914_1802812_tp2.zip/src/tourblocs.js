'use strict'
let Bloc = require('./bloc')
let fs = require('fs')

// Classe pour appeler les differents algos et garder les blocs en memoire
module.exports = class TourBlocs {

  constructor() {
    this.listeBlocs = []
    this.pileVorace = []
    this.hauteurActuelle = 0
  }

  creerBloc(hauteur, largeur, profondeur) {
    let surface = largeur * profondeur
    let nouveauBloc = new Bloc(hauteur, profondeur, largeur, surface)

    return nouveauBloc;
  }

  trierBlocsParSurface() {
    this.listeBlocs.sort((a, b) => {
      return b.surface - a.surface
    })
  }

  generateBlocksFromFile(file) {
    let array = fs.readFileSync(file).toString().split("\n")

    // On enleve le dernier element pcq c'est un espace
    if (array[array.length - 1] == '' || !array[array.length - 1]) {
      array.pop()
    }

    if (array[array.length - 1] == '' || !array[array.length - 1]) {
      array.pop()
    }

    //let nLines = 0
    array.forEach((line) => {
      let sides = line.split(' ')
      //nLines++
      //console.log("side:", sides)
      this.listeBlocs.push(this.creerBloc(parseInt(sides[0]), parseInt(sides[1]), parseInt(sides[2])))
    })
    //console.log("number of lines in file: ", nLines)
  }

  split() {
    this.listeBlocs = this.listeBlocs.reduce(function (acc, val) {
      var inner;
      if (acc.previous !== val.surface) {
        inner = [];
      } else {
        inner = acc.newArray.pop();
      }

      inner.push(val);
      acc.previous = val.surface;
      acc.newArray.push(inner);

      return acc;
    }, {
        previous: null,
        newArray: []
      }
    ).newArray;
  }

  vorace() {
    this.listeBlocs.forEach((bloc) => {
      bloc.some((b) => {

        // Critere probabiliste
        let randomValue = Math.random() * 100 + 1 // random * (max - min + 1) + min, max = 100, min = 1
        if (randomValue < 30) {
          return true;
        }

        if (!this.pileVorace.length) {
          this.pileVorace.push(bloc[0])
          return true;
        }

        let indexDernierBloc = this.pileVorace.length - 1
        // On verifie la regle formelle d'inclusion stricte de la base du nouveau bloc dans la surface du bloc receveur
        if (b.estPlusPetitQue(this.pileVorace[indexDernierBloc])) {
          // On ajoute le bloc dans pileVorace si c'est respecte.
          this.pileVorace.push(b)
          // On ajoute aussi la hauteur du bloc a la hauteur actuelle.
          this.hauteurActuelle += b.hauteur
          return true;
        }
      })
    })
    // On retourne la tour generee.
    //console.log(this.hauteurActuelle)
    return this.pileVorace
  }

  progDyn() {
    var listeTours = []
    let listeHauteurs = new Array(this.listeBlocs.length)

    for (var i = 0; i < this.listeBlocs.length; i++) {
      listeTours[i] = new TourBlocs()
      listeHauteurs[i] = this.listeBlocs[i].hauteur
    }

    for (var i = 0; i < this.listeBlocs.length; i++) {
      for (var j = 0; j < i; j++) {
        if (listeHauteurs[j] + this.listeBlocs[i].hauteur > listeHauteurs[i] && this.listeBlocs[i].estPlusPetitQue(this.listeBlocs[j])) {

          listeTours[i].pileVorace.length = 0
          listeTours[i].pileVorace = listeTours[j].pileVorace.concat()

          listeTours[i].pileVorace.push(this.listeBlocs[i])
          listeHauteurs[i] = listeHauteurs[j] + this.listeBlocs[i].hauteur
        }
      }
    }

    // Trouver la hauteur maximale et la tour maximale
    let hauteurMax = 0
    var tourMax = []

    listeHauteurs.forEach((hauteur, index) => {
      if (hauteur > hauteurMax) {
        hauteurMax = hauteur
        this.hauteurActuelle = hauteur;
        tourMax = listeTours[index].pileVorace
      }
    })
    return tourMax
  }

  tabou() {
    let nIteration = 0
    let tourEnCours = []
    let tourMax = []

    let listeTabou = []
    let listeVoisinage = this.listeBlocs

    // Mentionner dans l'enonce
    while (nIteration < 100) {
      // On choisit un bloc au hasard dans le voisinage.
      let blocActuel = listeVoisinage.splice([Math.floor(Math.random() * listeVoisinage.length)], 1)[0]

      let estPlaceBloc = false
      // On parcourt la tour en cours de construction.
      tourEnCours.forEach((b, index) => {
        // Si le bloc actuel peut fit sur le bloc courant de la tour qu'on parcourt,
        if (blocActuel.estPlusPetitQue(b)) {

          // On place le bloc actuel sur la tour a cette position-la.
          tourEnCours.splice(index, 0, blocActuel)
          estPlaceBloc = true

          // On enleve les blocs par-dessus le nouveau bloc, si ils ne respectent plus la regle formelle.
          enleverBlocs(index)
        }
      })

      // Si on a pas inseré le bloc actuel dans la tour, on le positionne à la fin de la tour.
      if (!estPlaceBloc) {
        tourEnCours.push(blocActuel)
        let index = tourEnCours.length - 1
        enleverBlocs(index)
      }

      // On met a jour la listeTabou.
      listeTabou.forEach((b, index) => {
        b.nIteration++
        if (b.nIteration === b.maxIteration) {
          let blocLibre = listeTabou.splice(index, 1)[0]
          delete blocLibre.maxIteration
          delete blocLibre.nIteration
          listeVoisinage.push(blocLibre)
        }
      })

      /*
      * Cette fonction permet de rearranger la tour suite a une insertion
      * en enlevant les blocs qui ne respectent plus la regle formelle.
      */
      function enleverBlocs(index) {
        let debut = index - 1
        let minimum = 0 // pour eviter un outOfBounds

        let listeBlocsEnleves = []
        for (var i = debut; i >= minimum; i--) {
          // Si le bloc actuel n'est pas plus petit que le bloc qui est au-dessus de lui
          if (!tourEnCours[i].estPlusPetitQue(tourEnCours[index])) {
            // Il sera enleve.
            listeBlocsEnleves.push(i)

            // On le place dans la liste tabou.
            let blockToPutInTabou = tourEnCours.slice(i, i + 1)[0]
            blockToPutInTabou.nIteration = 0
            blockToPutInTabou.maxIteration = Math.floor(Math.random() * 4 + 7) // random * (max - min + 1) + min, max = 10, min = 7
            listeTabou.push(blockToPutInTabou)
          }
        }

        // On enleve les blocs identifies plus tot de la tour en cours.
        listeBlocsEnleves.forEach((index) => {
          tourEnCours.splice(index, 1)
        })
      }
      /*
      * Fin de la fonction enleverBlocs(index)
      */

      // Le compteur est remis a zero si la hauteur trouvee est plus grande que celle stockee.
      if (tourEnCours.reduce((a, b) => a + b.hauteur, 0) > tourMax.reduce((a, b) => a + b.hauteur, 0)) {
        tourMax = tourEnCours
        nIteration = 0
      }
      nIteration++
    }
    return tourMax
  }
}
