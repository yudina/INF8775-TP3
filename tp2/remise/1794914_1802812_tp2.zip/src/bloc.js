'use strict'
// Classe pour gerer les dimensions des blocs
module.exports = class Bloc {

  constructor(hauteur, largeur, profondeur, surface) {
    this.hauteur = hauteur
    this.largeur = largeur
    this.profondeur = profondeur

    this.surface = surface || largeur * profondeur
  }

  // Regle formelle d'inclusion stricte de la base du nouveau bloc dans la surface du bloc receveur
  estPlusPetitQue(b) {
    return (this.largeur < b.largeur && this.profondeur < b.profondeur)
  }
}
