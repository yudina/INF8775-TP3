module.exports.DONNEES = [100, 500, 1000, 5000, 10000, 50000, 100000]
module.exports.FIELDS = ['Taille', '100', '500', '1000', '5000', '10000', '50000', '100000']
module.exports.MAX_FILE_PER_SET = 10
module.exports.SET_FIRST_LETTER = 'b'
