'use strict'
let Bloc = require('./bloc')
let Constantes = require('./constantes')
let Exporteur = require('./export')
let TourBlocs = require('./tourblocs')

let exportResult = []

console.log("Algorithme de programmation dynamique")
console.log("----------")

if(global.PATH) {
  var hrstart = process.hrtime();
  var tourProgDyn = new TourBlocs()
  tourProgDyn.generateBlocksFromFile(global.PATH)
  tourProgDyn.trierBlocsParSurface()
  let tour = tourProgDyn.progDyn()
  let diff = process.hrtime(hrstart);

  if(global.PRINT_TOWER) {
    console.log(tour.map(b => {
      return {
        'Hauteur': b.hauteur,
        'Largeur': b.largeur,
        'Profondeur': b.profondeur
      }
    }))
  }
  
  if(global.PRINT_TIME) {
    let time = (diff[0] * 1e9 + diff[1]) * 1e-6
    console.log(time)
  }

} 

// Cette partie du code est uniquement execute lorsqu'on execute node sur resultgen.js.
else {

  // Pour chaque taille d'exemplaire...
  for (var i = 0; i < Constantes.DONNEES.length; i++) {
    let moyennePourSerieHauteur = 0
    let moyennePourSerieTemps = 0
    // Chaque taille d'exemplaire contient un set de 1-10 fichiers.
    for (var j = 1; j <= Constantes.MAX_FILE_PER_SET; j++) {
      // On commence a noter le temps ici.
      var hrstart = process.hrtime();
      var tourProgDyn = new TourBlocs()
      tourProgDyn.generateBlocksFromFile(__dirname + '/data/' + Constantes.SET_FIRST_LETTER + Constantes.DONNEES[i] + '_' + j + ".txt")
      tourProgDyn.trierBlocsParSurface()
      tourProgDyn.progDyn()
      let diff = process.hrtime(hrstart);

      // L'algo a termine son execution. On ajoute le temps dans la moyenne.
      moyennePourSerieHauteur += tourProgDyn.hauteurActuelle
      moyennePourSerieTemps += (diff[0] * 1e9 + diff[1]) * 1e-6 // conversion en ms
    }
    moyennePourSerieHauteur /= Constantes.MAX_FILE_PER_SET
    moyennePourSerieTemps /= Constantes.MAX_FILE_PER_SET
    console.log("Hauteur pour la série " + Constantes.DONNEES[i] + " (moyenne) : " + moyennePourSerieHauteur)
    console.log("Temps pour la série " + Constantes.DONNEES[i] + " (moyenne) : " + moyennePourSerieTemps + ' ms')

    // On ajoute les donnees dans le but de les exporter en csv apres.
    exportResult.push({
      'Taille de l\'echantillon': Constantes.DONNEES[i],
      'Hauteur maximale (Moyenne)': moyennePourSerieHauteur,
      'Temps (moyenne)': moyennePourSerieTemps
    })
  }

  // On exporte les donnees en csv.
  Exporteur.exportToCsv('progdyn.csv', exportResult, Constantes.FIELDS)

}
