'use strict'
let Bloc = require('./bloc')
let Constantes = require('./constantes')
let Exporteur = require('./export')
let TourBlocs = require('./tourblocs')

let exportResult = []

console.log("Algorithme vorace probabiliste")
console.log("----------")

if(global.PATH) {
  var hrstart = process.hrtime();
  var tourVorace = new TourBlocs()
  tourVorace.generateBlocksFromFile(global.PATH)
  tourVorace.trierBlocsParSurface()
  tourVorace.split()
  let tour = tourVorace.vorace()
  let diff = process.hrtime(hrstart);

  if(global.PRINT_TOWER) {
    console.log(tour.map(b => {
      return {
        'Hauteur': b.hauteur,
        'Largeur': b.largeur,
        'Profondeur': b.profondeur
      }
    }))
  }

  if(global.PRINT_TIME) {
    let time = (diff[0] * 1e9 + diff[1]) * 1e-6
    console.log(time)
  }

} 

// Cette partie du code est uniquement execute lorsqu'on execute node sur resultgen.js.
else {
  let N_FOIS_VORACE = 10

  // Pour chaque taille d'exemplaire...
  for (var i = 0; i < Constantes.DONNEES.length; i++) {
    let moyennePourSerieHauteur = 0
    let moyennePourSerieTemps = 0
    // Chaque taille d'exemplaire contient un set de 1-10 fichiers.
    for (var j = 1; j <= Constantes.MAX_FILE_PER_SET; j++) {
      let moyennePourSetHauteur = 0
      let moyennePourSetTemps = 0
      // Pour l'algo vorace probabiliste, nous choisissons de l'executer 10 fois afin d'avoir une moyenne representative.
      for (var k = 0; k < N_FOIS_VORACE; k++) {
        // On commence a noter le temps ici.
        var hrstart = process.hrtime();
        var tourVorace = new TourBlocs()
        tourVorace.generateBlocksFromFile(__dirname + '/data/' + Constantes.SET_FIRST_LETTER + Constantes.DONNEES[i] + '_' + j + ".txt")
        tourVorace.trierBlocsParSurface()
        tourVorace.split()
        tourVorace.vorace()
        let diff = process.hrtime(hrstart);

        // L'algo a termine son execution. On ajoute le temps dans la moyenne.
        moyennePourSetHauteur += tourVorace.hauteurActuelle
        moyennePourSetTemps += (diff[0] * 1e9 + diff[1]) * 1e-6
      }

      moyennePourSerieHauteur += (moyennePourSetHauteur/N_FOIS_VORACE)
      moyennePourSerieTemps += (moyennePourSetTemps/N_FOIS_VORACE)
    }

    moyennePourSerieHauteur /= Constantes.MAX_FILE_PER_SET
    moyennePourSerieTemps /= Constantes.MAX_FILE_PER_SET
    console.log("Hauteur pour la série " + Constantes.DONNEES[i] + " (moyenne) : " + moyennePourSerieHauteur)
    console.log("Temps pour la série " + Constantes.DONNEES[i] + " (moyenne) : " + moyennePourSerieTemps + ' ms')

    // On ajoute les donnees dans le but de les exporter en csv apres.
    exportResult.push({
      'Taille de l\'echantillon': Constantes.DONNEES[i],
      'Hauteur maximale (Moyenne)': moyennePourSerieHauteur,
      'Temps (moyenne)': moyennePourSerieTemps
    })
  }

  // On exporte les donnees en csv.
  Exporteur.exportToCsv('vorace.csv', exportResult, Constantes.FIELDS)
}
